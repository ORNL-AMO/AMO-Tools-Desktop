/**
 * @license Angular v22.0.6
 * (c) 2010-2026 Google LLC. https://angular.dev/
 * License: MIT
 */

const Attribute = {
  JSACTION: 'jsaction'
};

export { Attribute };
//# sourceMappingURL=_attribute-chunk.mjs.map
